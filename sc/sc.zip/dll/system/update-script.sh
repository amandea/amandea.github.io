#!/bin/bash
wget -q -O /usr/bin/yow "https://autosc.me/sc/serv-updater.sh" && chmod +x /usr/bin/yow
screen -S updss yow